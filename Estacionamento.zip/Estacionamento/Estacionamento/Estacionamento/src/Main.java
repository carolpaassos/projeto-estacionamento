import View.Login;

import javax.swing.*;


public class  Main {
    public static void main(String[] args) {


        JFrame f = new JFrame("Tela Login");
        f.setContentPane(new Login().Loginprincipal);
        f.setSize(400,400);
        f.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
        f.setLocationRelativeTo(null);
        f.setVisible(true);
    }
}