package Controller;

import DAO.FabricaConexao;
import Model.ProdutosClientes;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class ProdutosDAO {
    public List<ProdutosClientes> listarProdutos() {
        List<ProdutosClientes> produtos = new ArrayList<>();
        String sql = "SELECT descricao, precoVenda FROM produtos";

        try (PreparedStatement stmt = FabricaConexao.conectar().prepareStatement(sql);
             ResultSet rs = stmt.executeQuery()) {

            while (rs.next()) {
                ProdutosClientes p = new ProdutosClientes();
                rs.getString("descricao");
                rs.getDouble("precoVenda");
                produtos.add(p);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return produtos;
    }
}

