package Controller;

import DAO.FabricaConexao;
import Model.ClientesModel;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class ClienteDAO {
    public ResultSet ListaClientes() {
        String sql = "SELECT * FROM Clientes";
        try {
            Connection conn = FabricaConexao.conectar();
            PreparedStatement stmt = conn.prepareStatement(sql);
            return stmt.executeQuery();
        } catch (SQLException e) {
            System.out.println("Erro ao validar login: " + e.getMessage());
        }
        return null;
    }

        public void InseririCliente (ClientesModel c){
            String sql = "INSERT INTO CLIENTES(nome,cpf,email,nascimento,telefone,endereco) VALUES (?, ?, ?, ?, ?, ?)";

            try {
                Connection conn = FabricaConexao.conectar();
                PreparedStatement stmt = conn.prepareStatement(sql);
                stmt.setString(1, c.getNome());
                stmt.setString(2, c.getCpf());
                stmt.setString(3, c.getEmail());
                stmt.setString(4, c.getNascimento());
                stmt.setString(5, c.getTelefone());
                stmt.setString(6, c.getEndereco());
                stmt.executeQuery();
            } catch (SQLException e) {
                System.out.println("Erro ao iserir: " + e.getMessage());
            }
        }

    public void updateClientes(ClientesModel c) {
        // Definir a query SQL de atualização
        String query = "UPDATE clientes SET nome = ?,cpf = ?, endereco = ?, telefone = ?, email = ?, sexo = ?, dataNascimento = ? WHERE id = ?";



        try (Connection connection = FabricaConexao.conectar();
             PreparedStatement pstmt = connection.prepareStatement(query)) {

            // Definir os parâmetros do PreparedStatement
            pstmt.setString(1, c.getNome());
            pstmt.setString(2, c.getCpf());
            pstmt.setString(3, c.getEndereco());
            pstmt.setString(4, c.getTelefone());
            pstmt.setString(5, c.getEmail());
            pstmt.setString(7, c.getNascimento());
            pstmt.setInt(8, c.getId());
            pstmt.executeUpdate();

        } catch (SQLException e) {
            e.printStackTrace();

        }
    }

    public void deletaClientes(ClientesModel c) {
        String query = "DELET FROM clientes WHERE id = ?";

        try(Connection connection = FabricaConexao.conectar();
            PreparedStatement pstmt = connection.prepareStatement(query)){
            pstmt.setInt(1,c.getId());
            pstmt.executeUpdate();
        } catch (SQLException e){
            e.printStackTrace();
        }
    }


}


