package View;

import Controller.LoginDAO;
import Model.UsuariosModel;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.FocusAdapter;
import java.awt.event.FocusEvent;

public class Login extends JFrame{
    public JPanel Loginprincipal;
    private JPanel PainelPrincipal;
    private JPanel painellateral;
    private JLabel Login;
    private JLabel Senha;
    private JTextField inputLogin;
    private JPasswordField inputSenha;
    private JButton JButtonLogar;
    private JButton JButtonSair;
    private JComboBox comboBox1;

    public Login() {


        JButtonLogar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {

                String login = inputLogin.getText();
                String senha = new String(inputSenha.getPassword());
                String perfil = String.valueOf(comboBox1.getSelectedItem());

                LoginDAO loginDAO = new LoginDAO();

                UsuariosModel resultado = loginDAO.validarLogin(login, senha, perfil);

                if(resultado!=null){
                    System.out.println("Login bem-sucedido!");


                    JFrame frame = (JFrame) SwingUtilities.getWindowAncestor(Loginprincipal);
                    frame.dispose();

                    SwingUtilities.invokeLater(() -> { // Chama a tela nova

                        Principal principal = new Principal();



                    if (resultado.getPerfil().equals("user")){
                        principal.jmCadastros.setEnabled(true);

                        principal.setVisible(true);

                    }else{
                        principal.setVisible(true);
                    }

                    });
                } else { // Quando digitar errado
                    System.out.println("Usuário ou senha inválidos.");
                    inputLogin.requestFocus(); // coloca o fot no cursor
                    inputLogin.setText(""); // Para ficarem vasios
                    inputSenha.setText("");

                    JOptionPane.showMessageDialog(null, "Login ou senha incorretos!");

                }

            }
        });

        inputLogin.addFocusListener(new FocusAdapter() {
            @Override
            public void focusGained(FocusEvent e) {
                super.focusGained(e);
                inputLogin.setBackground(Color.getHSBColor(255,218,185));
            }

            @Override
            public void focusLost(FocusEvent e) {
                super.focusLost(e);
                inputLogin.setBackground(Color.getHSBColor(255,218,185));
            }
        });

        inputSenha.addFocusListener(new FocusAdapter() {
            @Override
            public void focusGained(FocusEvent e) {
                super.focusGained(e);
                inputSenha.setBackground(Color.getHSBColor(255 ,218 ,185));
            }
            @Override
            public void focusLost(FocusEvent e) {
                super.focusLost(e);
                inputSenha.setBackground(Color.getHSBColor(55, 255, 55));
            }
        });
        JButtonSair.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                JOptionPane.showMessageDialog(null, "Saindo da Aplicação!");

                System.exit(0);
            }
        });


    }
}
