package View;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Principal extends JFrame{
    public JPanel painelPrincipal; //
    private JPanel JPanelTopo;
    private JPanel JPanelImagem;
    public JMenu jmCadastros;
    private JMenuItem jmItemClientes;
    private JPanel JpanelTopo;
    private JMenuBar JmBar;
    private JMenu jmRelatorios;
    private JMenu jmSair;
    private JMenuItem jmiSairConfirmar;
    private JMenu jmiVendas;
    private JMenu jmItemFornecedor;
    private JMenu jmItemProduto;
    private JMenuItem ItemNovaVenda;

    public Principal(){
       // O código abaixo não precisa de frame pois já é extendido do mesmo
        setTitle("Tela Principal");
        setSize (800, 600);
        setContentPane(painelPrincipal);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        jmItemClientes.addActionListener(new ActionListener(){
            @Override
                public void actionPerformed(ActionEvent e) { new Clientes();}
        });


        jmiSairConfirmar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                int resposta = JOptionPane.showConfirmDialog(null,"Deseja Sair",
                     "Saida do Sistema", JOptionPane.YES_NO_OPTION );
        if (resposta==JOptionPane.YES_OPTION){
                           System.exit(0);
                        }
                        else{
                           JOptionPane.showMessageDialog(null,"Obrigado por continuar");
                       }

            }
    });
        ItemNovaVenda.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {new Vendas();}
        });;
    }
    }

