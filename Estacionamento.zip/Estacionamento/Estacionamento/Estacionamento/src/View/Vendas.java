package View;

import Controller.ClienteDAO;
import DAO.FabricaConexao;
import Model.ClientesModel;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

public class Vendas extends JFrame {
    private JPanel PainelPrincipal;
    private JPanel PainelLateral;
    private JPanel PainelTopo;
    private JPanel central;
    private JPanel baixo;
    private JButton JButtonNovaVenda;
    private JButton JButtonFinalizarVenda;
    private JButton JButtonSair;
    private JTextField TxtFieldSelecioneOVendedor;
    private JTextField TxtFieldCodigoDaVenda;
    private JComboBox comboBox1;
    private JTextField TxtFieldSelecioneOCliente;
    private JTextField TxtFieldFormaDePagamento;
    private JRadioButton JButtonPixRadio;
    private JRadioButton JButtonCartãoDeCreditoRadio;
    private JRadioButton JButtonCartãoDeDebitoRadio;
    private JComboBox jcbCliente;
    private JTextField TxtFieldCodigoProduto;
    private JTextField TxtFieldDescriçaoProduto;
    private JTextField TxtFieldValorUnitario;
    private JTextField TxtField1;
    private JTextField TxtFieldDesconto;
    private JComboBox jcbProduto;
    private JTextField TxtFieldAcrescimo;
    private JTextField textField4;
    private JTextField TxtFieldQuantidade;
    private JTextField TxtFieldTotal;
    private JTextField textField8;
    private JTextField textField6;
    private JTextField textField9;
    private JTextField textField10;
    private JRadioButton JButtonBoletoRadio;
    private StringBuilder itensSelecionados;
    private JButton InserirButton;
    private JLabel jlabel;
    private JLabel jlTotal;

    double acumulado = 0.0;

    public Vendas() {
        setSize(1300, 700);
        setContentPane(PainelPrincipal);
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);
        setLocationRelativeTo(null);
        setVisible(true);
        ListaClientes();
        preencherComboBox();

        jcbProduto.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {

                String nomeSelecionado = (String) jcbProduto.getSelectedItem();

                if (nomeSelecionado != null) {
                    try {
                        String sql = "SELECT precoVenda FROM produtos WHERE descricao = ?";
                        PreparedStatement ps = FabricaConexao.conectar().prepareStatement(sql);
                        ps.setString(1, nomeSelecionado);
                        ResultSet rs = ps.executeQuery();

                        if (rs.next()) {
                            double preco = rs.getDouble("precoVenda");
                            textField4.setText(String.format("%.2f", preco));
                        } else {
                            textField4.setText("Não encontrado");
                        }

                        rs.close();
                        ps.close();
                    } catch (SQLException ex) {
                        JOptionPane.showMessageDialog(null, "Erro ao buscar preço: " + ex.getMessage());
                    }
                }


            }
        });
        InserirButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                 String item = (String) jcbProduto.getSelectedItem();
                 String item2 = (String) textField4.getText();
                 String valorTexto = textField4.getText();

                 if (! valorTexto.isEmpty()){
                     valorTexto = valorTexto.replace(",", ".");

                     double valorDouble = Double.parseDouble(valorTexto);

                     acumulado += valorDouble;

                     jlTotal.setText("Valor acumulado " + acumulado);

                     textField4.setText("");

                     itensSelecionados.append(item).append("<br>");
                     itensSelecionados.append(item2).append("<br>");

                     jlabel.setText("<html>" + itensSelecionados.toString() + "</html>");
                 }
            }
        });
    }

    private void ListaClientes() {
        try {
            ClientesModel cliente = new ClientesModel();
            ClienteDAO cli = new ClienteDAO();
            ResultSet rs = cli.ListaClientes();
            ArrayList<String> listaClientes = new ArrayList<>();
            while (rs.next()) {
                cliente.setNome(rs.getNString("nome"));
                cliente.setCpf(rs.getNString("cpf"));
                listaClientes.add(cliente.getNome() + " - " + cliente.getCpf());
            }
            for (String percorrer : listaClientes) {
                jcbCliente.addItem(percorrer);
            }
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }


    private void preencherComboBox() {
        try {
            String sql = "SELECT descricao FROM produtos";
            PreparedStatement ps = FabricaConexao.conectar().prepareStatement(sql);
            ResultSet rs = ps.executeQuery();

            while (rs.next()) {
                jcbProduto.addItem(rs.getString("descricao"));
            }
            rs.close();
            ps.close();
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "Erro ao carregar produtos: " + e.getMessage());
        }
    }
}
