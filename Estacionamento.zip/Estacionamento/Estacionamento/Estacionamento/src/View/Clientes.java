package View;
import javax.swing.*;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.FocusAdapter;
import java.awt.event.FocusEvent;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Vector;

import Controller.ClienteDAO;
import DAO.FabricaConexao;
import Model.ClientesModel;

public class Clientes extends JFrame{

    public JPanel PrincipalCliente;
    private JPanel PainelLateral;
    private JLabel JLNomeCliente;
    private JTextField TFNomeCliente;
    private JLabel JLcpfCliente;
    private JTextField TFcpf;
    private JTextField TFEndereco;
    private JLabel JLDataNasc;
    private JTextField TFDataNasc;
    private JPanel PainelInferior;
    private JButton JButtonSair;
    private JButton JButtonSalvar;
    private JButton JButtonDeletar;
    private JButton JButtonEditar;
    private JButton JButtonNovo;
    private JLabel JLTelefone;
    private JTextField TFTelefone;
    private JLabel JLEndereçoCliente;
    private JTextField TFEmail;
    private JLabel JLEmail;
    private JPanel PainelTabela;
    private JTable TabelaClientes;
    private JLabel JLid;
    private JTextField TFid;
    private JPanel PainelPrincipal;

    public Clientes(){

        setTitle("Exemplo de JTable");
        setSize(1000, 800);
        setContentPane(PrincipalCliente);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLocationRelativeTo(null); // Centraliza a janela
        setVisible(true);

        carregarDados();

        JButtonNovo.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {

                habilita();
                TFNomeCliente.requestFocus();

            }
        });

        JButtonSair.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                dispose();
            }
        });

        TFNomeCliente.addFocusListener(new FocusAdapter() {
            @Override
            public void focusGained(FocusEvent e) {
                super.focusGained(e);
                TFNomeCliente.setBackground(Color.getHSBColor(206, 209, 218));
            }

            @Override
            public void focusLost(FocusEvent e) {
                super.focusLost(e);
                TFNomeCliente.setBackground(Color.getHSBColor(170, 191, 222));
            }
        });

        JButtonSalvar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String nome = TFNomeCliente.getText().toString();
                String cpf = TFcpf.getText().toString();
                String telefone = TFTelefone.getText().toString();
                String dataN = TFDataNasc.getText().toString();
                String end = TFEndereco.getText().toString();
                String email = TFEmail.getText().toString();

                ClientesModel clientes = new ClientesModel();
                clientes.setNome(nome);
                clientes.setCpf(cpf);
                clientes.setEndereco(end);
                clientes.setTelefone(telefone);
                clientes.setEmail(email);
                clientes.setNascimento(dataN);
                ClienteDAO cliDAO = new ClienteDAO();
                cliDAO.InseririCliente(clientes);
                //limpaCampos();
                // desabilita();
                JButtonNovo.setEnabled(true);

            }
        });

        JButtonSair.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                System.exit(0);
            }
        });

        TabelaClientes.getSelectionModel().addListSelectionListener(new ListSelectionListener() {
            @Override
            public void valueChanged(ListSelectionEvent e) {
                habilita();
                if (!e.getValueIsAdjusting()) {
                    int linhaSelecionada = TabelaClientes.getSelectedRow();
                    if (linhaSelecionada != -1) {
                        // Preencher os campos de texto com os dados da linha selecionada
                        TFid.setText(TabelaClientes.getValueAt(linhaSelecionada, 0).toString());
                        TFNomeCliente.setText(TabelaClientes.getValueAt(linhaSelecionada, 1).toString());
                        TFcpf.setText(TabelaClientes.getValueAt(linhaSelecionada, 2).toString());
                        TFEndereco.setText(TabelaClientes.getValueAt(linhaSelecionada, 3).toString());
                        TFTelefone.setText(TabelaClientes.getValueAt(linhaSelecionada, 4).toString());
                        TFEmail.setText(TabelaClientes.getValueAt(linhaSelecionada, 5).toString());
                        TFDataNasc.setText(TabelaClientes.getValueAt(linhaSelecionada, 7).toString());
                    }
                }
            }
        });

        JButtonEditar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String id = TFid.getText().toString();
                String nome = TFNomeCliente.getText().toString();
                String cpf = TFcpf.getText().toString();
                String telefone = TFTelefone.getText().toString();
                String dataN = TFDataNasc.getText().toString();
                String end = TFEndereco.getText().toString();
                String email = TFEmail.getText().toString();
                ClientesModel clientes = new ClientesModel();
                clientes.setId(Integer.parseInt(id));
                clientes.setNome(nome);
                clientes.setCpf(cpf);
                clientes.setEndereco(end);
                clientes.setTelefone(telefone);
                clientes.setEmail(email);
                clientes.setNascimento(dataN);
                ClienteDAO cliDAO = new ClienteDAO();
                cliDAO.updateClientes(clientes);
                carregarDados();
            }
        });
    }
    public void limpaCampos() {
        TFNomeCliente.setText("");
        TFTelefone.setText("");
        TFcpf.setText("");
        TFDataNasc.setText("");
        TFEmail.setText("");
        TFEndereco.setText("");
    }
    public void desabilita(){
        TFNomeCliente.setEnabled(false);
        TFTelefone.setEnabled(false);
        TFcpf.setEnabled(false);
        TFDataNasc.setEnabled(false);
        TFEmail.setEnabled(false);
        TFEndereco.setEnabled(false);
        JButtonEditar.setEnabled(false);
        JButtonDeletar.setEnabled(false);
        JButtonSalvar.setEnabled(false);
    }
    public void habilita(){
        TFNomeCliente.setEnabled(true);
        TFTelefone.setEnabled(true);
        TFcpf.setEnabled(true);
        TFDataNasc.setEnabled(true);
        TFEmail.setEnabled(true);
        TFEndereco.setEnabled(true);
        JButtonEditar.setEnabled(true);
        JButtonDeletar.setEnabled(true);
        JButtonSalvar.setEnabled(true);
        JButtonNovo.setEnabled(false);
    }

    public void carregarDados() {
        // Conectar ao banco de dados e obter os dados
        try (Connection conn =FabricaConexao.conectar()) {
            String query = "SELECT id,nome, cpf, endereco, telefone, email, sexo, dataNascimento FROM clientes";
            Statement stmt = conn.createStatement();
            ResultSet rs = stmt.executeQuery(query);

            // Obter as colunas da tabela
            Vector<String> colunas = new Vector<>();
            colunas.add("Id");
            colunas.add("Nome");
            colunas.add("CPF");
            colunas.add("Endereço");
            colunas.add("Telefone");
            colunas.add("Email");
            colunas.add("Sexo");
            colunas.add("Data de Nascimento");

            // Obter os dados da tabela
            Vector<Vector<Object>> dados = new Vector<>();
            while (rs.next()) {
                Vector<Object> linha = new Vector<>();
                linha.add(rs.getString("id"));
                linha.add(rs.getString("nome"));
                linha.add(rs.getString("cpf"));
                linha.add(rs.getString("endereco"));
                linha.add(rs.getString("telefone"));
                linha.add(rs.getString("email"));
                linha.add(rs.getString("sexo"));
                linha.add(rs.getString("dataNascimento"));
                dados.add(linha);
            }

            // Criar a tabela com os dados e colunas
            TabelaClientes.setModel(new DefaultTableModel(dados, colunas));

        } catch (SQLException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(this, "Erro ao carregar dados", "Erro", JOptionPane.ERROR_MESSAGE);
        }
    }
}
