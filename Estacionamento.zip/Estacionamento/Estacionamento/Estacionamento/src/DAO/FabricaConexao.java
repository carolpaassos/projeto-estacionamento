package DAO;//package DAO;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class FabricaConexao {
    private static final String URL = "jdbc:mysql://localhost:3306/cacaudourado";
    private static final String USUARIO = "root"; //
    private static final String SENHA = "root";



    public static Connection conectar(){
        try { // Obrigatório
            Class.forName("com.mysql.cj.jdbc.Driver");
            return DriverManager.getConnection(URL, USUARIO, SENHA);
        } catch (ClassNotFoundException e) { // Obrigatório
            System.out.println("Driver JDBC não encntrado: " + e.getMessage());
        } catch (SQLException e){ // Obrigatório
            System.out.println("Erro ao conectar: " + e.getMessage());
        }
        return null;
    }
     public static void desconectar(Connection conn){
        if (conn != null){
            try{
                conn.close(); //
                System.out.println("Conexão encerrada.");
            } catch (SQLException e) {
                System.out.println("Erro ao fechar conexão: " + e.getMessage());
            }
        }
     }

}



